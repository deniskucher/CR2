#ifndef globalsH
#define globalsH
#include "usertype.h"
	////// ������� ���������� 
	////// ������� ���������� 
extern bool _RN17D02NN;
extern bool _RN17D02SA1;
extern bool _RN17D02SA2;
extern bool _RN17D02SGMN;
extern bool _RN17D02SGP;
extern bool _RN17D02SYMN;
extern bool _RN17D02SYP;
extern bool _RN17D03NN;
extern bool _RN17D03SA1;
extern bool _RN17D03SA2;
extern bool _RN17D03SGMN;
extern bool _RN17D03SGP;
extern bool _RN17D03SYMN;
extern bool _RN17D03SYP;
extern bool _RQ13S01NN;
extern bool _RQ13S01SA1;
extern bool _RQ13S01SA2;
extern bool _RQ13S01SG;
extern bool _RQ13S01SGM;
extern bool _RQ13S01SGR;
extern bool _RQ13S01SO;
extern bool _RQ13S01SY;
extern bool _RQ13S01SYM;
extern bool _RQ13S01SYR;
extern bool _RQ13S01SZ;

#endif

