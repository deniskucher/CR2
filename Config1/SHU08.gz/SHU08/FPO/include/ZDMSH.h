#ifndef ZDMSHH
#define ZDMSHH
#include "usertype.h"
#include "uIncludes.h"

  void _ZDMSH();

#endif