

         







#include "tasks.h"
//#include "KD.h"
#include "SigChange.h"
#include "uobjects.h"
#include "ko3.h"
//#include "vizov.h"
#include <cdsinch.h>
#include <stdio.h>
TBindSignal *Nal;
TBindSignal *Gen_Err;
TBindSignal *Gen_ErrP;

main(int argc, char*argv[])
{
  void (*start)();
  void (*finish)();
  start  =&cds::startSession;//NP
  finish =&cds::stopSession;//NP
 
  int i, res;
  cds::startSession();
  CDS_OCCUP = true; //NP
  Init_P();
//  Init_KD();
  InitObjects();
//  InitPulse();
//  pKO3 = new TKO3();
 /* MACRO_CreateSignal("ERR_COUNT_KO3", err_count, t_DSA, "FPO_main");
  MACRO_CreateSignal("SIZE_REZ", sizeRez, t_DSA, "FPO_main");
  MACRO_CreateSignal("GEN_ERROR", Gen_Err, t_DSD, "FPO_main");
  MACRO_CreateSignal("IMP_ERROR", Gen_ErrP, t_DSD, "FPO_main");
  MACRO_CreateSignal("REGIM_NALAD", Nal, t_DSD, "FPO_main");
*/
  cds::stopSession();
  CDS_OCCUP = false;//NP
  
  res = cdsinch_init(argc,argv, start, finish, NULL);
  while(!STOP_WORK)
   {
	if(cdsinch_begin() != -1)
  	 {	
    //  if (Get_Start_FPO())
       {
	    Read_Sig();
	//    KO3_Run();
        _TaskFPO();
        Write_Sig();             
       };
	 cdsinch_end();
	}	
   }
  
/*  
  
  
  
  
  for (;;) 
  {
	res = cdsinch_begin(start); 
//	cds::startSession();NP
    if (Get_Start_FPO())
    	{
	    Read_Sig();
	    KO3_Run();
//	    Naladka();
//	    KD_RUN();
        _TaskFPO();
//        Vizov();
        Write_Sig();             
       	};
//	cds::stopSession();NP
	res = cdsinch_end(finish);
  }
  */
}; 


