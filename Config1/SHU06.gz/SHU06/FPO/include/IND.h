#ifndef INDH
#define INDH
#include "usertype.h"
#include "uIncludes.h"

void _INDTC_model();
void _IND();
#endif