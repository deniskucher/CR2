#ifndef uObjectH
#define uObjectH
#include "usertype.h"
#include "uclasses.h"

extern _TMIG *_PI12AB01;
extern _TMIG *_PI12AB05;
extern _TMIG *_PI12AB09;

extern _TTAKT *_takt_tc;

extern void InitObjects();
extern void DeleteObjects();

#endif


