#include "tasks.h"
#include "IND.h"

void _TaskFPO()
{
  _IND();
}

