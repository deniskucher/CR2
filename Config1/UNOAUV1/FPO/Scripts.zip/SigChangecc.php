<?
//���������: ���� � ����������, ����������, ������ ������
$params = "lbd"; 
include "sintar2007.php";
?>

#include <unistd.h>
#include <cdsface.h>
#include <cdshead.h>

#include "globals.h"
#include "SigChange.h"
#include "typeBPO.h"
<?
global $signals;
$sigdb = ibase_connect($signals);
$cont = substr(basename($lbd,'.ib'),3); //��� �����������
//�������� �������, ������������� �������� ���
$qry = "select SC.SigName from SigCont SC, Controller C
  where C.Name='{$cont}' and SC.NodeID=C.NodeID 
  and  SC.TypeName='DI'  order by SC.SigName";
$sig_di   =ibase_query($sigdb, $qry);
$sig_di_p =ibase_query($sigdb, $qry);
$sig_di_r =ibase_query($sigdb, $qry);
$sig_di_w =ibase_query($sigdb, $qry);

$qry = "select SC.SigName from SigCont SC, Controller C
  where C.Name='{$cont}' and SC.NodeID=C.NodeID 
  and SC.TypeName='DO'  order by SC.SigName";
$sig_do   =ibase_query($sigdb, $qry);
$sig_do_p =ibase_query($sigdb, $qry);
$sig_do_r =ibase_query($sigdb, $qry);
$sig_do_w =ibase_query($sigdb, $qry);

/*$qry = "select SC.SigName from SigCont SC, Controller C
  where C.Name='{$cont}' and SC.NodeID=C.NodeID 
  and  SC.TypeName='KL' order by SC.SigName";
$sig_kl   =ibase_query($sigdb, $qry);
$sig_kl_p =ibase_query($sigdb, $qry);
$sig_kl_r =ibase_query($sigdb, $qry);
$sig_kl_w =ibase_query($sigdb, $qry);

$qry = "select SC.SigName from SigCont SC, Controller C
  where C.Name='{$cont}' and SC.NodeID=C.NodeID 
  and  SC.TypeName='PIN'  order by SC.SigName";
$sig_pin   =ibase_query($sigdb, $qry);
$sig_pin_p =ibase_query($sigdb, $qry);
$sig_pin_r =ibase_query($sigdb, $qry);
$sig_pin_w =ibase_query($sigdb, $qry);
*/
$qry = "select SC.SigName from SigCont SC, Controller C
  where C.Name='{$cont}' and SC.NodeID=C.NodeID 
  and  SC.TypeName='PFD' order by SC.SigName";
$sig_pfd   =ibase_query($sigdb, $qry);
$sig_pfd_p =ibase_query($sigdb, $qry);
$sig_pfd_r =ibase_query($sigdb, $qry);
$sig_pfd_w =ibase_query($sigdb, $qry);
/*
$qry = "select SC.SigName from SigCont SC, Controller C
  where C.Name='{$cont}' and SC.NodeID=C.NodeID 
  and SC.TypeName='AI'  order by SC.SigName";
$sig_ai   =ibase_query($sigdb, $qry);
$sig_ai_p =ibase_query($sigdb, $qry);
$sig_ai_r =ibase_query($sigdb, $qry);
$sig_ai_w =ibase_query($sigdb, $qry);

$qry = "select SC.SigName from SigCont SC, Controller C
  where C.Name='{$cont}' and SC.NodeID=C.NodeID 
  and  SC.TypeName='PFA' order by SC.SigName";
$sig_pfa   =ibase_query($sigdb, $qry);
$sig_pfa_p =ibase_query($sigdb, $qry);
$sig_pfa_r =ibase_query($sigdb, $qry);
$sig_pfa_w =ibase_query($sigdb, $qry);

$qry = "select SC.SigName from SigCont SC, Controller C
  where C.Name='{$cont}' and SC.NodeID=C.NodeID 
  and  SC.TypeName='KO'  order by SC.SigName";
$sig_ko   =ibase_query($sigdb, $qry);
$sig_ko_p =ibase_query($sigdb, $qry);
$sig_ko_r =ibase_query($sigdb, $qry);
$sig_ko_w =ibase_query($sigdb, $qry);
*/
 while ($sig = ibase_fetch_object($sig_di))
 {
/*	if((substr($sig->SIGNAME,-4) == 'KNMC')
  or (substr($sig->SIGNAME,-4) == 'KNMG'))*/
       echo "  char *p{$sig->SIGNAME};\n";
}
 while ($sig = ibase_fetch_object($sig_do))
 {
//	if ((substr($sig->SIGNAME,-3) == 'DTS'))
       echo "  char *p{$sig->SIGNAME};\n";
}
 while ($sig = ibase_fetch_object($sig_pfd))
 {
//	if(substr($sig->SIGNAME,-2) == 'TS')
       echo "  char *p{$sig->SIGNAME};\n";
 }
 ?>

  void Init_P()
 {
<?
 $n=0; 
 while ($sig = ibase_fetch_object($sig_di_p))
  {
 // if((substr($sig->SIGNAME,-4) == 'KNMC')
 // or (substr($sig->SIGNAME,-4) == 'KNMG'))
  echo "  GET_REF(p{$sig->SIGNAME},char,DEF_DI_BY_ID,{$n});\n";
  $n++;
  }
 $n=0; 
 while ($sig = ibase_fetch_object($sig_do_p))
  {
  //if ((substr($sig->SIGNAME,-3) == 'DTS'))
  echo "  GET_REF(p{$sig->SIGNAME},char,DEF_DO_BY_ID,{$n});\n";
  $n++;
  }
 $n=0; 
 while ($sig = ibase_fetch_object($sig_pfd_p))
  {
 // if(substr($sig->SIGNAME,-2) == 'TS')
  echo "  GET_REF(p{$sig->SIGNAME},char,DEF_PFD_BY_ID,{$n});\n";
  $n++;
  }
 ?>
  };

  void Read_Sig()
  {
<?
echo "	////// ������� DI \n";
  while ($sig = ibase_fetch_object($sig_di_r))
      {
	/*if((substr($sig->SIGNAME,-4) == 'KNMC')
  or (substr($sig->SIGNAME,-4) == 'KNMG'))*/
       echo "  _{$sig->SIGNAME}=(bool)*p{$sig->SIGNAME};\n";
}

  echo "	////// ������� PFD \n";
  while ($sig = ibase_fetch_object($sig_pfd_r))
      {
//	if(substr($sig->SIGNAME,-2) == 'TS')
       echo "  _{$sig->SIGNAME}=(bool)*p{$sig->SIGNAME};\n";
 }

?>
  };

  void Write_Sig()
  {
<?
echo "	////// ������� DI \n";
  while ($sig = ibase_fetch_object($sig_di_w))
     {
/*	if((substr($sig->SIGNAME,-4) == 'KNMC')
  or (substr($sig->SIGNAME,-4) == 'KNMG'))*/
       echo "  *p{$sig->SIGNAME}=(char)_{$sig->SIGNAME};\n";
}
echo "	////// ������� DO \n";
  while ($sig = ibase_fetch_object($sig_do_w))
     {
//	if ((substr($sig->SIGNAME,-3) == 'DTS'))
       echo "  *p{$sig->SIGNAME}=(char)_{$sig->SIGNAME};\n";
}

echo "	////// ������� PFD \n";
  while ($sig = ibase_fetch_object($sig_pfd_w))
     {
//	if(substr($sig->SIGNAME,-2) == 'TS')
       echo "  *p{$sig->SIGNAME}=(char)_{$sig->SIGNAME};\n";
 }

?>
  };
