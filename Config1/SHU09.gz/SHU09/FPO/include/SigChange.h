#ifndef SigChangeH
#define SigChangeH

extern char *pPI21AC01DTS;
extern char *pPI21AC01TS;
extern char *pPI21AD03DTS;
extern char *pPI21AD03TS;
extern char *pPI21AE05DTS;
extern char *pPI21AE05TS;
extern char *pPI21AJ03KNMC;
extern char *pPI21AJ05KNMG;
extern void Read_Sig();
extern void Write_Sig();
extern void Init_P();
#endif
