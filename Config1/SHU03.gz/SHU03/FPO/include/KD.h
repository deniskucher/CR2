
#ifndef KDH
#define KDH
#include "KD_Classes.h"

  extern bool _M255F_1;
  extern bool _M698F_1;
  extern bool _M701F_1;
  extern bool _M702F_1;
  const short KOL_AI1=4;
  const short KOL_AI2=(0/2);
  const short KOL_AI3=(3/3);

  extern void KD_RUN(); 
  extern void Init_KD();

#endif

