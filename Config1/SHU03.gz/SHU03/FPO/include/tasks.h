#ifndef tasksH
#define tasksH

void _TaskFPO();

#endif
