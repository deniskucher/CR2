//������������� � �������� ��������
#include "usertype.h"
#include "pulse.h"
#include "globals.h"
#include "vizov.h"
#include "cdsface.h"
TBindSignal *Nal;
TBindSignal *Gen_Err;
TBindSignal *Gen_ErrP;
int Nalad=0;
int Is_Gen_Err=0;
int Is_Gen_ErrP=0;
short time1=10;    //  1 second
  _TSPulse1 *Pl_TK10S09NSSH;
  _TSPulse1 *Pl_TK10S10NES;
  _TSPulse1 *Pl_TD10S15NES;
  _TSPulse1 *Pl_TC10S16NES;
  _TSPulse1 *Pl_TC10S26NES;
  _TSPulse1 *Pl_VG16S04NES;
  _TSPulse1 *Pl_VG16S01NES;
  _TSPulse1 *Pl_VG16S02NES;
  _TSPulse1 *Pl_VG16S03NES;
  _TSPulse1 *Pl_TE10S02NES;
  _TSPulse1 *Pl_TK20S10NES;
  _TSPulse1 *Pl_TK10S10NP;
  _TSPulse1 *Pl_TK10S09NP;
  _TSPulse1 *Pl_TD10S15NP;
  _TSPulse1 *Pl_TC10S16NP;
  _TSPulse1 *Pl_TC10S26NP;
  _TSPulse1 *Pl_VG16S04NP;
  _TSPulse1 *Pl_VG16S01NP;
  _TSPulse1 *Pl_VG16S02NP;
  _TSPulse1 *Pl_VG16S03NP;
  _TSPulse1 *Pl_TE10S02NP;
  _TSPulse1 *Pl_TK20S10NP;
  _TSPulse1 *Pl_TK10S09NSTH;
  _TSPulse1 *Pl_TD10S15F;
  _TSPulse1 *Pl_TE10S02F;
  _TSPulse1 *Pl_TK20S10F;
  _TSPulse1 *Pl_VG16S01F;
  _TSPulse1 *Pl_TK10S10F;
  _TSPulse1 *Pl_TC10S16F;
  _TSPulse1 *Pl_TC10S26F;
  _TSPulse1 *Pl_T111B03F;
  _TSPulse1 *Pl_T115B08F;
  _TSPulse1 *Pl_T110B02F;
  _TSPulse1 *Pl_T703B01F;
  _TSPulse1 *Pl_T127B01F;
  _TSPulse1 *Pl_Y317B02F;
  _TSPulse1 *Pl_VG16S02F;
  _TSPulse1 *Pl_VG16S03SA2F;
  _TSPulse1 *Pl_VG16S03SADF;
  _TSPulse1 *Pl_VG16S04SA1F;
  _TSPulse1 *Pl_VG16S04SA2F;
  _TSPulse1 *Pl_VG16S04SADF;
  _TSPulse1 *Pl_VG16S03F;
  _TSPulse1 *Pl_VG16S04F;
  _TSPulse1 *Pl_T11XB0F;
  _TSPulse1 *Pl_D8MC_6F;
  _TSPulse1 *Pl_D8MC_7F;
  _TSPulse1 *Pl_D8MC_8F;
  _TSPulse1 *Pl_D8MC_9F;
  _TSPulse1 *Pl_TD10S15SA1F;
  _TSPulse1 *Pl_TD10S15SA2F;
  _TSPulse1 *Pl_TD10S15SADF;
  _TSPulse1 *Pl_TE10S02SA1F;
  _TSPulse1 *Pl_TE10S02SA2F;
  _TSPulse1 *Pl_TE10S02SADF;
  _TSPulse1 *Pl_TK20S10SA1F;
  _TSPulse1 *Pl_TK20S10SA2F;
  _TSPulse1 *Pl_TK20S10SADF;
  _TSPulse1 *Pl_Y1XXB0F;
  _TSPulse1 *Pl_YA11TXXXF;
  _TSPulse1 *Pl_TK10S10SA1F;
  _TSPulse1 *Pl_TK10S10SA2F;
  _TSPulse1 *Pl_TK10S10SADF;
  _TSPulse1 *Pl_TK10S09SA1F;
  _TSPulse1 *Pl_TK10S09SA2F;
  _TSPulse1 *Pl_TC10S16SA1F;
  _TSPulse1 *Pl_TC10S16SA2F;
  _TSPulse1 *Pl_TC10S16SADF;
  _TSPulse1 *Pl_TC10S26SA1F;
  _TSPulse1 *Pl_TC10S26SA2F;
  _TSPulse1 *Pl_TC10S26SADF;
  _TSPulse1 *Pl_VG16S01SA1F;
  _TSPulse1 *Pl_VG16S01SA2F;
  _TSPulse1 *Pl_VG16S01SADF;
  _TSPulse1 *Pl_VG16S02SA1F;
  _TSPulse1 *Pl_VG16S02SA2F;
  _TSPulse1 *Pl_VG16S02SADF;
  _TSPulse1 *Pl_VG16S03SA1F;
  _TSPulse1 *Pl_SHU4DEBLKNF;
  _TSPulse1 *Pl_SHU4SBRMKNF;
  _TSPulse1 *Pl_SHU4SPRLKNF;
  _TSPulse1 *Pl_T126B0F;
   bool bic_TD10S15F; 
   bool bic_TE10S02F; 
   bool bic_TK20S10F; 
   bool bic_VG16S01F; 
   bool bic_TK10S10F; 
   bool bic_TC10S16F; 
   bool bic_TC10S26F; 
   bool bic_T111B03F; 
   bool bic_T115B08F; 
   bool bic_T110B02F; 
   bool bic_T703B01F; 
   bool bic_T127B01F; 
   bool bic_Y317B02F; 
   bool bic_VG16S02F; 
   bool bic_VG16S03SA2F; 
   bool bic_VG16S03SADF; 
   bool bic_VG16S04SA1F; 
   bool bic_VG16S04SA2F; 
   bool bic_VG16S04SADF; 
   bool bic_VG16S03F; 
   bool bic_VG16S04F; 
   bool bic_T11XB0F; 
   bool bic_D8MC_6F; 
   bool bic_D8MC_7F; 
   bool bic_D8MC_8F; 
   bool bic_D8MC_9F; 
   bool bic_TD10S15SA1F; 
   bool bic_TD10S15SA2F; 
   bool bic_TD10S15SADF; 
   bool bic_TE10S02SA1F; 
   bool bic_TE10S02SA2F; 
   bool bic_TE10S02SADF; 
   bool bic_TK20S10SA1F; 
   bool bic_TK20S10SA2F; 
   bool bic_TK20S10SADF; 
   bool bic_Y1XXB0F; 
   bool bic_YA11TXXXF; 
   bool bic_TK10S10SA1F; 
   bool bic_TK10S10SA2F; 
   bool bic_TK10S10SADF; 
   bool bic_TK10S09SA1F; 
   bool bic_TK10S09SA2F; 
   bool bic_TC10S16SA1F; 
   bool bic_TC10S16SA2F; 
   bool bic_TC10S16SADF; 
   bool bic_TC10S26SA1F; 
   bool bic_TC10S26SA2F; 
   bool bic_TC10S26SADF; 
   bool bic_VG16S01SA1F; 
   bool bic_VG16S01SA2F; 
   bool bic_VG16S01SADF; 
   bool bic_VG16S02SA1F; 
   bool bic_VG16S02SA2F; 
   bool bic_VG16S02SADF; 
   bool bic_VG16S03SA1F; 
   bool bic_SHU4DEBLKNF; 
   bool bic_SHU4SBRMKNF; 
   bool bic_SHU4SPRLKNF; 
   bool bic_T126B0F; 
  _TSPulse1 *Pl_IS_GEN_ERR;
bool IS_GEN_ERR_Pl=false;
bool Zero=false;
bool _NFPO_D,_NFPO_NP;
void InitPulse()
{
  Pl_TK10S09NSSH = new _TSPulse1(0,false);
  Pl_TK10S10NES = new _TSPulse1(0,false);
  Pl_TD10S15NES = new _TSPulse1(0,false);
  Pl_TC10S16NES = new _TSPulse1(0,false);
  Pl_TC10S26NES = new _TSPulse1(0,false);
  Pl_VG16S04NES = new _TSPulse1(0,false);
  Pl_VG16S01NES = new _TSPulse1(0,false);
  Pl_VG16S02NES = new _TSPulse1(0,false);
  Pl_VG16S03NES = new _TSPulse1(0,false);
  Pl_TE10S02NES = new _TSPulse1(0,false);
  Pl_TK20S10NES = new _TSPulse1(0,false);
  Pl_TK10S10NP = new _TSPulse1(0,false);
  Pl_TK10S09NP = new _TSPulse1(0,false);
  Pl_TD10S15NP = new _TSPulse1(0,false);
  Pl_TC10S16NP = new _TSPulse1(0,false);
  Pl_TC10S26NP = new _TSPulse1(0,false);
  Pl_VG16S04NP = new _TSPulse1(0,false);
  Pl_VG16S01NP = new _TSPulse1(0,false);
  Pl_VG16S02NP = new _TSPulse1(0,false);
  Pl_VG16S03NP = new _TSPulse1(0,false);
  Pl_TE10S02NP = new _TSPulse1(0,false);
  Pl_TK20S10NP = new _TSPulse1(0,false);
  Pl_TK10S09NSTH = new _TSPulse1(0,false);
  Pl_TD10S15F = new _TSPulse1(0,false);
  Pl_TE10S02F = new _TSPulse1(0,false);
  Pl_TK20S10F = new _TSPulse1(0,false);
  Pl_VG16S01F = new _TSPulse1(0,false);
  Pl_TK10S10F = new _TSPulse1(0,false);
  Pl_TC10S16F = new _TSPulse1(0,false);
  Pl_TC10S26F = new _TSPulse1(0,false);
  Pl_T111B03F = new _TSPulse1(0,false);
  Pl_T115B08F = new _TSPulse1(0,false);
  Pl_T110B02F = new _TSPulse1(0,false);
  Pl_T703B01F = new _TSPulse1(0,false);
  Pl_T127B01F = new _TSPulse1(0,false);
  Pl_Y317B02F = new _TSPulse1(0,false);
  Pl_VG16S02F = new _TSPulse1(0,false);
  Pl_VG16S03SA2F = new _TSPulse1(0,false);
  Pl_VG16S03SADF = new _TSPulse1(0,false);
  Pl_VG16S04SA1F = new _TSPulse1(0,false);
  Pl_VG16S04SA2F = new _TSPulse1(0,false);
  Pl_VG16S04SADF = new _TSPulse1(0,false);
  Pl_VG16S03F = new _TSPulse1(0,false);
  Pl_VG16S04F = new _TSPulse1(0,false);
  Pl_T11XB0F = new _TSPulse1(0,false);
  Pl_D8MC_6F = new _TSPulse1(0,false);
  Pl_D8MC_7F = new _TSPulse1(0,false);
  Pl_D8MC_8F = new _TSPulse1(0,false);
  Pl_D8MC_9F = new _TSPulse1(0,false);
  Pl_TD10S15SA1F = new _TSPulse1(0,false);
  Pl_TD10S15SA2F = new _TSPulse1(0,false);
  Pl_TD10S15SADF = new _TSPulse1(0,false);
  Pl_TE10S02SA1F = new _TSPulse1(0,false);
  Pl_TE10S02SA2F = new _TSPulse1(0,false);
  Pl_TE10S02SADF = new _TSPulse1(0,false);
  Pl_TK20S10SA1F = new _TSPulse1(0,false);
  Pl_TK20S10SA2F = new _TSPulse1(0,false);
  Pl_TK20S10SADF = new _TSPulse1(0,false);
  Pl_Y1XXB0F = new _TSPulse1(0,false);
  Pl_YA11TXXXF = new _TSPulse1(0,false);
  Pl_TK10S10SA1F = new _TSPulse1(0,false);
  Pl_TK10S10SA2F = new _TSPulse1(0,false);
  Pl_TK10S10SADF = new _TSPulse1(0,false);
  Pl_TK10S09SA1F = new _TSPulse1(0,false);
  Pl_TK10S09SA2F = new _TSPulse1(0,false);
  Pl_TC10S16SA1F = new _TSPulse1(0,false);
  Pl_TC10S16SA2F = new _TSPulse1(0,false);
  Pl_TC10S16SADF = new _TSPulse1(0,false);
  Pl_TC10S26SA1F = new _TSPulse1(0,false);
  Pl_TC10S26SA2F = new _TSPulse1(0,false);
  Pl_TC10S26SADF = new _TSPulse1(0,false);
  Pl_VG16S01SA1F = new _TSPulse1(0,false);
  Pl_VG16S01SA2F = new _TSPulse1(0,false);
  Pl_VG16S01SADF = new _TSPulse1(0,false);
  Pl_VG16S02SA1F = new _TSPulse1(0,false);
  Pl_VG16S02SA2F = new _TSPulse1(0,false);
  Pl_VG16S02SADF = new _TSPulse1(0,false);
  Pl_VG16S03SA1F = new _TSPulse1(0,false);
  Pl_SHU4DEBLKNF = new _TSPulse1(0,false);
  Pl_SHU4SBRMKNF = new _TSPulse1(0,false);
  Pl_SHU4SPRLKNF = new _TSPulse1(0,false);
  Pl_T126B0F = new _TSPulse1(0,false);
  Pl_IS_GEN_ERR = new _TSPulse1(0,false);
}
void Vizov()
{
////////////////// Vizov ////////////////////////////////////////////////// 
IS_GEN_ERR_Pl=Pl_IS_GEN_ERR->_SPulse((bool)Is_Gen_ErrP,time1);
_NEISPR_4 = Zero
    ||  _VG16S04SA1F
    ||  _TD10S15SA1F
    ||  _TE10S02SA1F
    ||  _TK20S10SA1F
    ||  _TK10S10SA1F
    ||  _TK10S09SA1F
    ||  _TC10S16SA1F
    ||  _TC10S26SA1F
    ||  _VG16S01SA1F
    ||  _VG16S02SA1F
    ||  _VG16S03SA1F
    ||  _VG16S03SA2F
    ||  _VG16S04SA2F
    ||  _TD10S15SA2F
    ||  _TE10S02SA2F
    ||  _TK20S10SA2F
    ||  _TK10S10SA2F
    ||  _TK10S09SA2F
    ||  _TC10S16SA2F
    ||  _TC10S26SA2F
    ||  _VG16S01SA2F
    ||  _VG16S02SA2F
    ||  _VG16S03SADF
    ||  _VG16S04SADF
    ||  _TD10S15SADF
    ||  _TE10S02SADF
    ||  _TK20S10SADF
    ||  _TK10S10SADF
    ||  _TC10S16SADF
    ||  _TC10S26SADF
    ||  _VG16S01SADF
    ||  _VG16S02SADF
    ||  _SHU4DEBLKNF
    ||  _SHU4SBRMKNF
    ||  _SHU4SPRLKNF
;
_NFPO_NP = Zero
   || Pl_TK10S09NSSH->_SPulse(_TK10S09NSSH,time1)
   || Pl_TK10S10NES->_SPulse(_TK10S10NES,time1)
   || Pl_TD10S15NES->_SPulse(_TD10S15NES,time1)
   || Pl_TC10S16NES->_SPulse(_TC10S16NES,time1)
   || Pl_TC10S26NES->_SPulse(_TC10S26NES,time1)
   || Pl_VG16S04NES->_SPulse(_VG16S04NES,time1)
   || Pl_VG16S01NES->_SPulse(_VG16S01NES,time1)
   || Pl_VG16S02NES->_SPulse(_VG16S02NES,time1)
   || Pl_VG16S03NES->_SPulse(_VG16S03NES,time1)
   || Pl_TE10S02NES->_SPulse(_TE10S02NES,time1)
   || Pl_TK20S10NES->_SPulse(_TK20S10NES,time1)
   || Pl_TK10S10NP->_SPulse(_TK10S10NP,time1)
   || Pl_TK10S09NP->_SPulse(_TK10S09NP,time1)
   || Pl_TD10S15NP->_SPulse(_TD10S15NP,time1)
   || Pl_TC10S16NP->_SPulse(_TC10S16NP,time1)
   || Pl_TC10S26NP->_SPulse(_TC10S26NP,time1)
   || Pl_VG16S04NP->_SPulse(_VG16S04NP,time1)
   || Pl_VG16S01NP->_SPulse(_VG16S01NP,time1)
   || Pl_VG16S02NP->_SPulse(_VG16S02NP,time1)
   || Pl_VG16S03NP->_SPulse(_VG16S03NP,time1)
   || Pl_TE10S02NP->_SPulse(_TE10S02NP,time1)
   || Pl_TK20S10NP->_SPulse(_TK20S10NP,time1)
   || Pl_TK10S09NSTH->_SPulse(_TK10S09NSTH,time1)
   || Pl_VG16S04SA1F->_SPulse(_VG16S04SA1F,time1)
   || Pl_TD10S15SA1F->_SPulse(_TD10S15SA1F,time1)
   || Pl_TE10S02SA1F->_SPulse(_TE10S02SA1F,time1)
   || Pl_TK20S10SA1F->_SPulse(_TK20S10SA1F,time1)
   || Pl_TK10S10SA1F->_SPulse(_TK10S10SA1F,time1)
   || Pl_TK10S09SA1F->_SPulse(_TK10S09SA1F,time1)
   || Pl_TC10S16SA1F->_SPulse(_TC10S16SA1F,time1)
   || Pl_TC10S26SA1F->_SPulse(_TC10S26SA1F,time1)
   || Pl_VG16S01SA1F->_SPulse(_VG16S01SA1F,time1)
   || Pl_VG16S02SA1F->_SPulse(_VG16S02SA1F,time1)
   || Pl_VG16S03SA1F->_SPulse(_VG16S03SA1F,time1)
   || Pl_VG16S03SA2F->_SPulse(_VG16S03SA2F,time1)
   || Pl_VG16S04SA2F->_SPulse(_VG16S04SA2F,time1)
   || Pl_TD10S15SA2F->_SPulse(_TD10S15SA2F,time1)
   || Pl_TE10S02SA2F->_SPulse(_TE10S02SA2F,time1)
   || Pl_TK20S10SA2F->_SPulse(_TK20S10SA2F,time1)
   || Pl_TK10S10SA2F->_SPulse(_TK10S10SA2F,time1)
   || Pl_TK10S09SA2F->_SPulse(_TK10S09SA2F,time1)
   || Pl_TC10S16SA2F->_SPulse(_TC10S16SA2F,time1)
   || Pl_TC10S26SA2F->_SPulse(_TC10S26SA2F,time1)
   || Pl_VG16S01SA2F->_SPulse(_VG16S01SA2F,time1)
   || Pl_VG16S02SA2F->_SPulse(_VG16S02SA2F,time1)
   || Pl_VG16S03SADF->_SPulse(_VG16S03SADF,time1)
   || Pl_VG16S04SADF->_SPulse(_VG16S04SADF,time1)
   || Pl_TD10S15SADF->_SPulse(_TD10S15SADF,time1)
   || Pl_TE10S02SADF->_SPulse(_TE10S02SADF,time1)
   || Pl_TK20S10SADF->_SPulse(_TK20S10SADF,time1)
   || Pl_TK10S10SADF->_SPulse(_TK10S10SADF,time1)
   || Pl_TC10S16SADF->_SPulse(_TC10S16SADF,time1)
   || Pl_TC10S26SADF->_SPulse(_TC10S26SADF,time1)
   || Pl_VG16S01SADF->_SPulse(_VG16S01SADF,time1)
   || Pl_VG16S02SADF->_SPulse(_VG16S02SADF,time1)
   || Pl_SHU4DEBLKNF->_SPulse(_SHU4DEBLKNF,time1)
   || Pl_SHU4SBRMKNF->_SPulse(_SHU4SBRMKNF,time1)
   || Pl_SHU4SPRLKNF->_SPulse(_SHU4SPRLKNF,time1)
;
_NEISPR_3 = Zero
    ||  _TK10S09NSSH
    ||  _TK10S10NES
    ||  _TD10S15NES
    ||  _TC10S16NES
    ||  _TC10S26NES
    ||  _VG16S04NES
    ||  _VG16S01NES
    ||  _VG16S02NES
    ||  _VG16S03NES
    ||  _TE10S02NES
    ||  _TK20S10NES
    ||  _TK10S10NP
    ||  _TK10S09NP
    ||  _TD10S15NP
    ||  _TC10S16NP
    ||  _TC10S26NP
    ||  _VG16S04NP
    ||  _VG16S01NP
    ||  _VG16S02NP
    ||  _VG16S03NP
    ||  _TE10S02NP
    ||  _TK20S10NP
    ||  _TK10S09NSTH
;
   bic_TK10S10F = _TK10S10F  && !_TK10S10KRS;
   bic_TC10S16F = _TC10S16F  && !_TC10S16KRS;
   bic_TC10S26F = _TC10S26F  && !_TC10S26KRS;
   bic_TD10S15F = _TD10S15F  && !_TD10S15KRS;
   bic_TE10S02F = _TE10S02F  && !_TE10S02KRS;
   bic_TK20S10F = _TK20S10F  && !_TK20S10KRS;
   bic_T111B03F = _T111B03F  && !_T111B03KRS;
   bic_T115B08F = _T115B08F  && !_T115B08KRS;
   bic_T110B02F = _T110B02F  && !_T110B02KRS;
   bic_T703B01F = _T703B01F  && !_T703B01KRS;
   bic_T127B01F = _T127B01F  && !_T127B01KRS;
   bic_VG16S01F = _VG16S01F  && !_VG16S01KRS;
   bic_VG16S02F = _VG16S02F  && !_VG16S02KRS;
   bic_VG16S03F = _VG16S03F  && !_VG16S03KRS;
   bic_VG16S04F = _VG16S04F  && !_VG16S04KRS;
   bic_D8MC_6F = _D8MC_6F  && !_D8MC_6KRS;
   bic_D8MC_7F = _D8MC_7F  && !_D8MC_7KRS;
   bic_D8MC_8F = _D8MC_8F  && !_D8MC_8KRS;
   bic_D8MC_9F = _D8MC_9F  && !_D8MC_9KRS;
   bic_Y317B02F = _Y317B02F  && !_Y317B02KRS;
// ����� ��������
_NEISPR_1 = Zero
    ||  bic_TD10S15F 
    ||  bic_TE10S02F 
    ||  bic_TK20S10F 
    ||  bic_VG16S01F 
    ||  bic_TK10S10F 
    ||  bic_TC10S16F 
    ||  bic_TC10S26F 
    ||  bic_T111B03F 
    ||  bic_T115B08F 
    ||  bic_T110B02F 
    ||  bic_T703B01F 
    ||  bic_T127B01F 
    ||  bic_Y317B02F 
    ||  bic_VG16S02F 
    ||  bic_VG16S03F 
    ||  bic_VG16S04F 
    ||  bic_D8MC_6F 
    ||  bic_D8MC_7F 
    ||  bic_D8MC_8F 
    ||  bic_D8MC_9F 
;
// ����� �������
_NEISPR_2 = Zero
;
_NFPO_D = Zero
    ||  Pl_TK10S10F->_SPulse(bic_TK10S10F,time1) 
    ||  Pl_TC10S16F->_SPulse(bic_TC10S16F,time1) 
    ||  Pl_TC10S26F->_SPulse(bic_TC10S26F,time1) 
    ||  Pl_TD10S15F->_SPulse(bic_TD10S15F,time1) 
    ||  Pl_TE10S02F->_SPulse(bic_TE10S02F,time1) 
    ||  Pl_TK20S10F->_SPulse(bic_TK20S10F,time1) 
    ||  Pl_T111B03F->_SPulse(bic_T111B03F,time1) 
    ||  Pl_T115B08F->_SPulse(bic_T115B08F,time1) 
    ||  Pl_T110B02F->_SPulse(bic_T110B02F,time1) 
    ||  Pl_T703B01F->_SPulse(bic_T703B01F,time1) 
    ||  Pl_T127B01F->_SPulse(bic_T127B01F,time1) 
    ||  Pl_VG16S01F->_SPulse(bic_VG16S01F,time1) 
    ||  Pl_VG16S02F->_SPulse(bic_VG16S02F,time1) 
    ||  Pl_VG16S03F->_SPulse(bic_VG16S03F,time1) 
    ||  Pl_VG16S04F->_SPulse(bic_VG16S04F,time1) 
    ||  Pl_D8MC_6F->_SPulse(bic_D8MC_6F,time1) 
    ||  Pl_D8MC_7F->_SPulse(bic_D8MC_7F,time1) 
    ||  Pl_D8MC_8F->_SPulse(bic_D8MC_8F,time1) 
    ||  Pl_D8MC_9F->_SPulse(bic_D8MC_9F,time1) 
    ||  Pl_Y317B02F->_SPulse(bic_Y317B02F,time1) 
;
_NEISPR_0 = _NEISPR_1  || _NEISPR_2  ||  _NEISPR_3 ||  _NEISPR_4;
_NFPO     = _NFPO_D    || _NFPO_NP;
////////////////// Emergency governer switching OFF ///////////////////////
   _SHU4APN_SP  
   = Is_Gen_ErrP;
   _SHU4APN  
      =   Is_Gen_Err;  // 
}
void Naladka()
{
Nal -> Get_Value(Nalad);
Gen_Err -> Get_Value(Is_Gen_Err);
Gen_ErrP -> Get_Value(Is_Gen_ErrP);
}
