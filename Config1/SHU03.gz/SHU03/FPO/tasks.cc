#include "tasks.h"
#include "shu903.h"

void _TaskFPO()
{
  _shu903();
}

