#ifndef usertypeH
#define usertypeH
#include "Sinlib.h"
#include "uIncludes.h"

#define smallint	short
#define byte	char

#endif
