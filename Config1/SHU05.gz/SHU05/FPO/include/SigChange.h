#ifndef SigChangeH
#define SigChangeH

extern char *pRN17D01NN;
extern char *pRN17D01SA1;
extern char *pRN17D01SA2;
extern char *pRN17D01SGMN;
extern char *pRN17D01SGP;
extern char *pRN17D01SYMN;
extern char *pRN17D01SYP;
extern char *pRN21S05NN;
extern char *pRN21S05SA1;
extern char *pRN21S05SA2;
extern char *pRN21S05SG;
extern char *pRN21S05SGM;
extern char *pRN21S05SGR;
extern char *pRN21S05SO;
extern char *pRN21S05SY;
extern char *pRN21S05SYM;
extern char *pRN21S05SYR;
extern char *pRN21S05SZ;
extern char *pRN21S06NN;
extern char *pRN21S06SA1;
extern char *pRN21S06SA2;
extern char *pRN21S06SG;
extern char *pRN21S06SGM;
extern char *pRN21S06SGR;
extern char *pRN21S06SO;
extern char *pRN21S06SY;
extern char *pRN21S06SYM;
extern char *pRN21S06SYR;
extern char *pRN21S06SZ;
extern void Read_Sig();
extern void Write_Sig();
extern void Init_P();
#endif
