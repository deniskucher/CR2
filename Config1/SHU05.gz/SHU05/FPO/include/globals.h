#ifndef globalsH
#define globalsH
#include "usertype.h"
	////// ������� ���������� 
	////// ������� ���������� 
extern bool _RN17D01NN;
extern bool _RN17D01SA1;
extern bool _RN17D01SA2;
extern bool _RN17D01SGMN;
extern bool _RN17D01SGP;
extern bool _RN17D01SYMN;
extern bool _RN17D01SYP;
extern bool _RN21S05NN;
extern bool _RN21S05SA1;
extern bool _RN21S05SA2;
extern bool _RN21S05SG;
extern bool _RN21S05SGM;
extern bool _RN21S05SGR;
extern bool _RN21S05SO;
extern bool _RN21S05SY;
extern bool _RN21S05SYM;
extern bool _RN21S05SYR;
extern bool _RN21S05SZ;
extern bool _RN21S06NN;
extern bool _RN21S06SA1;
extern bool _RN21S06SA2;
extern bool _RN21S06SG;
extern bool _RN21S06SGM;
extern bool _RN21S06SGR;
extern bool _RN21S06SO;
extern bool _RN21S06SY;
extern bool _RN21S06SYM;
extern bool _RN21S06SYR;
extern bool _RN21S06SZ;

#endif

